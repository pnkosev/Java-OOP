package pr03_barracks_wars_new_factory.interfaces;

public interface Destroyable {
    
    int getHealth();
    
    void setHealth(int health);
}
