package pr03_barracks_wars_new_factory.core.commands;

import pr03_barracks_wars_new_factory.interfaces.Executable;
import pr03_barracks_wars_new_factory.interfaces.Repository;
import pr03_barracks_wars_new_factory.interfaces.UnitFactory;

public abstract class Command implements Executable {
    private String[] data;
    private Repository repository;
    private UnitFactory unitFactory;

    protected Command(String[] data, Repository repository, UnitFactory unitFactory) {
        this.data = data;
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    public String[] getData() {
        return this.data;
    }

    public Repository getRepository() {
        return this.repository;
    }

    public UnitFactory getUnitFactory() {
        return this.unitFactory;
    }
}
