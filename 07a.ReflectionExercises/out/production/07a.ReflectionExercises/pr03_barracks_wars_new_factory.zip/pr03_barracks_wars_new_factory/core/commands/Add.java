package pr03_barracks_wars_new_factory.core.commands;

import jdk.jshell.spi.ExecutionControl;
import pr03_barracks_wars_new_factory.interfaces.Repository;
import pr03_barracks_wars_new_factory.interfaces.Unit;
import pr03_barracks_wars_new_factory.interfaces.UnitFactory;

public class Add extends Command {
    public Add(String[] data, Repository repository, UnitFactory unitFactory) {
        super(data, repository, unitFactory);
    }

    @Override
    public String execute() throws ExecutionControl.NotImplementedException {
        String unitType = this.getData()[1];
        Unit unitToAdd = this.getUnitFactory().createUnit(unitType);
        this.getRepository().addUnit(unitToAdd);
        return unitType + " added!";
    }
}
