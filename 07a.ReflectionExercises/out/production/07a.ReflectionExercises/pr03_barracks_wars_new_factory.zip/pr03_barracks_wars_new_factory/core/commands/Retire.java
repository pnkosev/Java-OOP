package pr03_barracks_wars_new_factory.core.commands;

import jdk.jshell.spi.ExecutionControl;
import pr03_barracks_wars_new_factory.interfaces.Repository;
import pr03_barracks_wars_new_factory.interfaces.UnitFactory;

import javax.naming.OperationNotSupportedException;

public class Retire extends Command {
    public Retire(String[] data, Repository repository, UnitFactory unitFactory) {
        super(data, repository, unitFactory);
    }

    @Override
    public String execute() throws OperationNotSupportedException, ExecutionControl.NotImplementedException {
        String type = this.getData()[1];
        String result;

        try {
            this.getRepository().removeUnit(type);
            result = type + " retired!";
        } catch (OperationNotSupportedException e) {
            result = e.getMessage();
        }

        return  result;
    }
}
