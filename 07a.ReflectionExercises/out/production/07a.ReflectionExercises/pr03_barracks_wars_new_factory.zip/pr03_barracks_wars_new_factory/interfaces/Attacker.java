package pr03_barracks_wars_new_factory.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
