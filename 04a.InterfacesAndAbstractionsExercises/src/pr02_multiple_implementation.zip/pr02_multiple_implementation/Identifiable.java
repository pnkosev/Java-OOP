package pr02_multiple_implementation;

public interface Identifiable {
    String getId();
}
