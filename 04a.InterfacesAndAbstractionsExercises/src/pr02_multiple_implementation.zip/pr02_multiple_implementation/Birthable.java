package pr02_multiple_implementation;

public interface Birthable {
    String getBirthDate();
}
