package pr07_collection_hierarchy.interfaces;

public interface MyList extends AddRemovable {
    int getUsed();
}
