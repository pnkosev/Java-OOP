package pr07_collection_hierarchy.interfaces;

public interface AddRemovable extends Addable {
    String remove();
}
