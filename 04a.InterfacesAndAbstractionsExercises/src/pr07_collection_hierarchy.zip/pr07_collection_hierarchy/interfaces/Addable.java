package pr07_collection_hierarchy.interfaces;

public interface Addable {
    int add(String s);
}
