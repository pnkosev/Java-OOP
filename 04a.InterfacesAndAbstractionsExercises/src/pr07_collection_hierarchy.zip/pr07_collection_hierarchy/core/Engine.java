package pr07_collection_hierarchy.core;

public interface Engine {
    void run();
}
