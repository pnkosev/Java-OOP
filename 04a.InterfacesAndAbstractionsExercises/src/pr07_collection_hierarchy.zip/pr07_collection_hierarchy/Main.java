package pr07_collection_hierarchy;

import pr07_collection_hierarchy.core.EngineImpl;

public class Main {
    public static void main(String[] args) {
        EngineImpl engine = new EngineImpl();
        engine.run();
    }
}
