package pr03_birthday_celebrations;

public interface Birthable {
    String getBirthDate();
}
