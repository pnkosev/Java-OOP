package pr03_birthday_celebrations;

public interface Identifiable {
    String getId();
}
