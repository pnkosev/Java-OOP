package pr05_telephony;

public interface Browsable {
    String browse();
}
