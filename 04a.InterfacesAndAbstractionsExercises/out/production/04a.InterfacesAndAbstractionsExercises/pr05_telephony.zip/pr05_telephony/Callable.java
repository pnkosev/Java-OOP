package pr05_telephony;

public interface Callable {
    String call();
}
