package pr06_military_elite.interfaces;

public interface Private extends Soldier {
    double getSalary();
}
