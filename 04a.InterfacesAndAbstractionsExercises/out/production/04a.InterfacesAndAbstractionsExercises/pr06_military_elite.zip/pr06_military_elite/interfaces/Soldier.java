package pr06_military_elite.interfaces;

public interface Soldier {
    int getId();
    String getFirstName();
    String getLastName();
}
