package pr06_military_elite.interfaces;

public interface Spy {
    String getCodeNumber();
}
