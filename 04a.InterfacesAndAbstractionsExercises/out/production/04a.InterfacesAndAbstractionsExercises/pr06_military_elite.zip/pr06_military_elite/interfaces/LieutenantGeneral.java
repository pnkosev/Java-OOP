package pr06_military_elite.interfaces;

public interface LieutenantGeneral extends Private {
    void addPrivate(Private p);
}
