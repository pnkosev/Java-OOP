package pr06_military_elite.core;

public interface Engine {
    void run();
}
