package pr06_military_elite.utils.readers;

public interface InputReader {
    String readLine();
}
