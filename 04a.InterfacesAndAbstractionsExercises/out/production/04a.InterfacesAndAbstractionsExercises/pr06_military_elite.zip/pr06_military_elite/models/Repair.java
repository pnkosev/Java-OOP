package pr06_military_elite.models;

public interface Repair {
}
