package pr04_food_shortage;

public interface Person {
    String getName();
    int getAge();
}
