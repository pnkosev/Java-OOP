package pr04_food_shortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
