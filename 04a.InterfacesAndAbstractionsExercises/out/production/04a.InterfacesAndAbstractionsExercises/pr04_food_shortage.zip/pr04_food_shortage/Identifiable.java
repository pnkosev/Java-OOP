package pr04_food_shortage;

public interface Identifiable {
    String getId();
}
