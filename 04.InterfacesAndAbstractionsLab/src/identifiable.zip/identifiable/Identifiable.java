package identifiable;

public interface Identifiable {
    String getId();
}
